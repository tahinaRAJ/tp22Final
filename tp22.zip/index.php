<?php
header("location: page/page1.php");
exit();
?> 